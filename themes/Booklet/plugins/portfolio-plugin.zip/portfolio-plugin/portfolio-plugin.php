<?php

/*
Plugin Name: Portfolio Plugin
Plugin URI: http://www.silviuandrei.eu
Description: Portfolio Plugin.
Author: Silviu Andrei
Author URI: http://www.silviuandrei.eu
Version: 1.0
*/

class SPSA_Folio_Post_Type {

	public function __construct() {
		$this->register_post_type();
		$this->taxonomies();
	}
	
	public function register_post_type() {
		$args = array(
			'labels' => array(
				'name' => 'Portfolio',
				'singular_name' => 'Portfolio',
				'add_new' => 'Add New Item',
				'add_new_item' => 'Add New Item',
				'edit_item' => 'Edit Item',
				'new_item' => 'Add New Item',
				'view_item' =>'View Item',
				'search_items' => 'Search Portfolio',
				'not_found' => 'No Items Found',
				'not_found_in_trash' => 'No Items Found in Trash'
			),
			'query_var' => 'portfolio',
			'rewrite' => array(
				'slug' => 'portfolio'
			),
			'public' => true,
			// 'menu_position' => 25,
			// 'menu_icon' => admin_url() . 'images/media-button-video.gif',
			'supports' => array(
				'title',
				'thumbnail',
				'editor'
			)
		);
		register_post_type('spsa_folio', $args);
	}
	
	public function taxonomies() {
		$taxonomies = array();
		
		$taxonomies['filter'] = array(
			'hierarchical' => true,
			'query_var' => 'folio_filter',
			'rewrite' => array(
				'slug' => 'portfolio/filter',
			),
			'labels' => array(
				'name' => 'Filter',
				'singular_name' => 'Filter',
				'edit_item' => 'Edit Filter',
				'update_item' => 'Update Filter',
				'add_new_item' => 'Add Filter',
				'new_item_name' => 'Add New Filter',
				'all_items' => 'All Filters',
				'search_items' => 'Search Filters',
				'popular_items' => 'Popular Filters',
				'separate_items_with_comments' => 'Separate filters with commas',
				'add_or_remove_items' => 'Add or remove filters',
				'choose_from_most_used' => 'Choose from most used filters'
			)
		);
		
		$this->register_all_taxonomies($taxonomies);
	}
	
	public function register_all_taxonomies($taxonomies) {
		foreach($taxonomies as $name => $arr) {
			register_taxonomy($name, array('spsa_folio'), $arr);
		}
	}

}

add_action('init', function() {
	new SPSA_Folio_Post_Type();
});

?>